## Copyright (c) 2004-2012, The Regents of the University of California,
## through Lawrence Berkeley National Laboratory
## (subject to receipt of any required approvals from
## the U.S. Dept. of Energy).  All rights reserved.
"""
Software version
"""
NL_VERSION = "4.3.0"
NL_CREATE_DATE = "$Date$"[7:-1].strip()
NL_COPYRIGHT = """Copyright (c) 2004-2012, The Regents of the University of California, through
Lawrence Berkeley National Laboratory (subject to receipt of any required
approvals from the U.S. Dept. of Energy).  All rights reserved."""
